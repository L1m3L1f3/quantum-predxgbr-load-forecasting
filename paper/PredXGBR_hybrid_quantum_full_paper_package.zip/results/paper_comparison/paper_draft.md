# Hybrid Quantum-Enhanced XGBoost with Sequential Residual Correction for Short-Term Electrical Load Forecasting

## Abstract

Short-term electrical load forecasting is important for operational planning, demand response, and real-time grid management. The PredXGBR study reported strong XGBoost results on five public load datasets using short-term lag features. This paper extends that setting with a residual-enhanced forecasting pipeline that combines a local XGBoost baseline, hybrid quantum-enhanced residual features, and sequential residual postprocessing. Experiments are conducted on all five datasets used in the PredXGBR paper: PJM, PJME, PJMW, AEP, and Dayton. The proposed full pipeline improves MAPE over the reported PredXGBR-1 baseline on all five datasets, with improvements ranging from 13.45% to 39.32%. The strongest overall result is obtained by the sequential residual postprocess, while hybrid quantum-enhanced residual features provide slight but dataset-dependent improvement over the local XGBoost baseline. The results should therefore be interpreted as evidence for a useful hybrid residual forecasting pipeline, not as universal quantum advantage.

## Keywords

Short-term load forecasting; XGBoost; residual learning; hybrid quantum machine learning; variational quantum circuit; PredXGBR; time-series forecasting.

## 1. Introduction

Electrical load forecasting supports scheduling, balancing, and resource planning in modern power systems. Small improvements in forecast accuracy can reduce operational cost and improve grid reliability. Recent work has shown that gradient-boosted tree models can be highly competitive for short-term electrical load forecasting, especially when they are paired with lagged load statistics.

The PredXGBR paper proposed an XGBoost-based framework using short-term lag features and reported strong performance across PJM, PJME, PJMW, AEP, and Dayton datasets. However, even a strong baseline leaves structured residual errors. This work investigates whether residual learning and hybrid quantum-enhanced features can reduce those errors while preserving the practical strength of XGBoost.

The objective is not to replace the classical model with a pure quantum model. Instead, the proposed method keeps XGBoost as the primary forecaster and uses residual modules to model the remaining error. This is a pragmatic hybrid design: the classical model handles the dominant trend and seasonality, while residual correction modules focus on the remaining forecast error.

## 2. Problem Statement

Given historical hourly load values, the task is to predict the next load value using engineered temporal features. For each timestamp \(t\), the model receives lagged and rolling load features and predicts \(\\hat y_t\). The primary metrics are mean absolute percentage error (MAPE) and coefficient of determination (R2), matching the PredXGBR paper.

The residual after the local XGBoost forecast is defined as:

\[
r_t = y_t - \\hat y_t^{XGB}
\]

The final corrected forecast is:

\[
\\hat y_t^{final} = \\hat y_t^{XGB} + \\hat r_t
\]

where \(\\hat r_t\) is estimated by either a hybrid quantum residual model or a sequential residual postprocess.

## 3. Proposed Method

The proposed framework contains four evaluated model variants:

1. Local XGBoost baseline: an XGBoost regressor trained with original paper-style temporal features.
2. Static hybrid quantum: a residual correction model using quantum-enhanced residual features.
3. Hybrid quantum sequential: a sequential residual correction variant using hybrid quantum residual information.
4. Best sequential postprocess: a non-quantum sequential residual correction selected from validation behavior.

The hybrid quantum branch transforms reduced classical features into quantum expectation values. The feature vector is scaled into rotation angles, encoded with angle embedding, processed by a variational quantum circuit, and measured using Pauli-Z expectation values. These quantum features are then used in a residual readout model.

The evaluated quantum circuit follows this high-level structure:

1. PCA-based feature reduction to match the number of qubits.
2. Angle embedding of reduced features.
3. Strongly entangling variational layers.
4. Pauli-Z measurement on each qubit.
5. Residual readout and correction of the XGBoost forecast.

## 4. Experimental Setup

The experiments use the five datasets reported in the PredXGBR paper. The comparison uses the paper-style original feature mode so that the evaluation is aligned with the reported PredXGBR-1 baseline. For each dataset, local results are compared against the matching paper baseline MAPE and R2 from Table 3.

The datasets and paper baselines are:

| Dataset | Paper PredXGBR-1 MAPE | Paper PredXGBR-1 R2 |
| --- | ---: | ---: |
| PJM | 1.07 | 0.99 |
| PJME | 1.28 | 0.99 |
| PJMW | 1.07 | 0.98 |
| AEP | 0.98 | 0.99 |
| Dayton | 1.12 | 0.99 |

## 5. Evaluation Metrics

MAPE is used as the primary error metric:

\[
MAPE = \\frac{100}{n} \\sum_i \\left| \\frac{y_i - \\hat y_i}{y_i} \\right|
\]

R2 measures goodness of fit:

\[
R^2 = 1 - \\frac{\\sum_i (y_i - \\hat y_i)^2}{\\sum_i (y_i - \\bar y)^2}
\]

Lower MAPE is better, and higher R2 is better.

## 6. Results

Table 1 compares the proposed results against the paper baseline for every dataset.

| Dataset | Paper MAPE | Local XGBoost MAPE | Static Hybrid MAPE | Sequential Hybrid MAPE | Best Postprocess MAPE | Best Model | Win/Lose vs Paper | Improvement % |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| AEP | 0.9800 | 0.7194 | 0.7208 | 0.7200 | 0.6959 | Best sequential postprocess | WIN | 28.9943 |
| DAYTON | 1.1200 | 0.7515 | 0.7552 | 0.7506 | 0.7234 | Best sequential postprocess | WIN | 35.4138 |
| PJM | 1.0700 | 0.9408 | 0.9380 | 0.9410 | 0.9261 | Best sequential postprocess | WIN | 13.4491 |
| PJME | 1.2800 | 0.8127 | 0.8099 | 0.7937 | 0.7767 | Best sequential postprocess | WIN | 39.3236 |
| PJMW | 1.0700 | 0.8754 | 0.8688 | 0.8715 | 0.8148 | Best sequential postprocess | WIN | 23.8500 |

Table 2 summarizes R2 performance.

| Dataset | Paper R2 | Best Local R2 | Best Hybrid R2 | Best Overall R2 |
| --- | --- | --- | --- | --- |
| PJM | 0.9900 | 0.9939 | 0.9939 | 0.9941 |
| PJME | 0.9900 | 0.9962 | 0.9964 | 0.9966 |
| PJMW | 0.9800 | 0.9944 | 0.9946 | 0.9956 |
| AEP | 0.9900 | 0.9959 | 0.9959 | 0.9962 |
| DAYTON | 0.9900 | 0.9956 | 0.9956 | 0.9960 |

Table 3 lists the best model selected for each dataset.

| Dataset | Best Model | MAPE | R2 | MAE | RMSE | Improvement % |
| --- | --- | --- | --- | --- | --- | --- |
| AEP | Best sequential postprocess | 0.6959 | 0.9962 | 102.7830 | 152.1539 | 28.9943 |
| DAYTON | Best sequential postprocess | 0.7234 | 0.9960 | 14.9018 | 24.0203 | 35.4138 |
| PJM | Best sequential postprocess | 0.9261 | 0.9941 | 287.9832 | 440.3684 | 13.4491 |
| PJME | Best sequential postprocess | 0.7767 | 0.9966 | 245.7637 | 377.3443 | 39.3236 |
| PJMW | Best sequential postprocess | 0.8148 | 0.9956 | 46.7374 | 68.5920 | 23.8500 |

## 7. Discussion

The full proposed pipeline beats the reported PredXGBR-1 MAPE on all five datasets. The best MAPE values are 0.9261 on PJM, 0.7767 on PJME, 0.8148 on PJMW, 0.6959 on AEP, and 0.7234 on Dayton. The largest relative improvement is observed on PJME, while the smallest relative improvement is observed on PJM.

The best model for every dataset is the best sequential postprocess. This indicates that residual structure remains after the local XGBoost baseline and that a sequential residual correction can exploit that structure effectively.

The hybrid quantum results are more nuanced. Static or sequential hybrid quantum variants improve over the local XGBoost baseline in 6/10 hybrid comparisons. The improvement is visible on some datasets, including PJM, PJME, PJMW, and Dayton depending on the hybrid variant, but it is not consistent across all datasets. Therefore, the correct claim is that hybrid quantum-enhanced features provide slight, dataset-dependent improvement over the local XGBoost baseline when observed across datasets.

## 8. Figures

The generated paper figures are:

- `results/paper_comparison/all_datasets_mape_plot.png`
- `results/paper_comparison/all_datasets_r2_plot.png`
- `results/paper_comparison/paper_vs_our_best_mape.png`
- `results/paper_comparison/local_xgboost_vs_hybrid_quantum.png`
- `results/paper_comparison/proposed_method_mape_comparison.png`
- `results/paper_comparison/proposed_method_r2_comparison.png`
- `results/paper_comparison/proposed_method_improvement_percent.png`
- `figures/hybrid_quantum_xgboost_architecture.png`

## 9. Contributions

The main contributions are:

1. A full all-dataset comparison against the PredXGBR paper baseline rather than a single-dataset comparison.
2. A residual-enhanced XGBoost forecasting pipeline for short-term load prediction.
3. A hybrid quantum residual feature branch based on variational quantum circuit measurements.
4. A sequential residual postprocessing method that improves MAPE across all five datasets.
5. A reproducible results package containing CSV tables, plots, sticker-style win/loss summaries, and paper-ready draft files.

## 10. Limitations

The reported winning results use the original paper-style feature mode to align with the PredXGBR comparison. A stricter causal-only feature setting should also be reported if the target venue requires leakage-resistant forecasting. The hybrid quantum component does not consistently outperform the local XGBoost baseline across every dataset, so the paper should avoid claiming universal quantum advantage. The quantum circuit is evaluated with a limited number of qubits and layers, and broader tuning or real quantum hardware execution remains future work.

## 11. Future Work

Future work should evaluate stricter causal features, add weather and calendar covariates, tune the quantum circuit architecture, compare against LightGBM and CatBoost, and test graph-based extensions when reliable multi-region grid topology is available. A GNN-VQC model may be useful for cross-region forecasting, but it should be treated as a future extension rather than the main contribution of the present paper.

## 12. Conclusion

This paper presents a hybrid residual-enhanced XGBoost framework for short-term electrical load forecasting. Across all five PredXGBR datasets, the proposed full pipeline improves over the reported PredXGBR-1 MAPE and maintains high R2. The strongest empirical contribution is the sequential residual postprocess. Hybrid quantum-enhanced residual features provide slight but dataset-dependent improvements over the local XGBoost baseline; therefore, the results support a careful hybrid forecasting claim rather than an exaggerated quantum advantage claim.

## Paper-Ready Claim

The proposed full pipeline outperforms the published PredXGBR baseline on all five datasets in MAPE and R2. The strongest gains are obtained by residual/sequential postprocessing, while hybrid quantum-enhanced residual features provide slight, dataset-dependent improvements over the local XGBoost baseline.
